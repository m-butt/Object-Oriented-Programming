#include<iostream>
using namespace std;
int rec_ncr(int n,int r)
{
//write your code here for Q1

}

bool equal(int ** matrix1, int** matrix2,int** matrix3,int row, int column)
{
//write your code here for Q2

}


int sum_of_Perfect(int num,int mid)
{
//write your code here for Q3

}
